# IPSA-Simulator
In Place Sorting Algorithm Simulator using Python GUI Library: TKinter

This project “IPSA Simulator” is aimed to help students visualize the sorting algorithms in an interesting way 
that will help them understanding it better and make them comfortable with computer science concepts. 
This will simulate the sorting algorithm through bar graphs (representing data).

Currently it includes,  
1. Bubble Sort,
2. Insertion Sort,
3. Selection Sort.
